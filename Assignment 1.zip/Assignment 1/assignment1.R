
# Install and import libraries
library(tidyverse)
library(lubridate)
library(GGally)
library(zoo)

#-------------------------------------------------------------------------------
# Import data
weather_data <- read.csv("weather_data.csv", sep = ",")
View(weather_data)

sales_data <- read.csv("sales_data.csv", sep = ",")
View(sales_data)

#-------------------------------------------------------------------------------
# Explore the data
str(weather_data)
dim(weather_data)
colnames(weather_data)

str(sales_data)
dim(sales_data)
colnames(sales_data)

#-------------------------------------------------------------------------------
# Find NAs and 0s
colSums(is.na(weather_data))
colSums(weather_data == 0)

colSums(is.na(sales_data))
colSums(sales_data == 0)

#------------------------------ Formatting Data --------------------------------
# Format "Date" columns
weather_data$Date <- as.Date(weather_data$Date, format = "%d/%m/%Y")
weather_data <- weather_data[order(as.Date(weather_data$Date, format = "%d/%m/%Y")), ]

sales_data$ï..Date <- as.Date(sales_data$ï..Date, format = "%d/%m/%Y")

# Rename "Rainfall" column
weather_data <- subset(weather_data, select = -c(Rainfall))
#names(weather_data)[4] <- "Rainfall"

# Create "month", "year", and "year_month" variable
weather_data$month <- months(as.POSIXlt(weather_data$Date, format = "%Y-%m-%d"))
weather_data$year <- year(as.POSIXlt(weather_data$Date, format = "%Y-%m-%d"))
weather_data$yr_month <- as.yearmon(weather_data$Date)

sales_data$month <- months(as.POSIXlt(sales_data$ï..Date, format = "%Y-%m-%d"))
sales_data$year <- year(as.POSIXlt(sales_data$ï..Date, format = "%Y-%m-%d"))
sales_data$yr_month <- as.yearmon(sales_data$ï..Date)

# Remove column
sales_data <- subset(sales_data, select = -c(X))

# Remove rows from "weather_data" so number of rows is equivalent 
weather_data <- weather_data[-c(1:8), ]

# Rename columns
colnames(weather_data) <- c("date", "min_temp", "max_temp", "rainfall", "evap", 
                            "sun_sh_hr", "dir_max_wind", "spd_max_wind", "tm_max_wind", 
                            "9am_temp", "9am_hum", "9am_cld_amnt", "9am_wind_dir", "9am_wind_spd", "9am_pres",
                            "3pm_temp", "3pm_hum", "3pm_cld_amnt", "3pm_wind_dir", "3pm_wind_spd", "3pm_pres",
                            "month", "year", "yr_month")

colnames(sales_data) <- c("date", "day", "ubereats", "menulog", "deliveroo", "card", "cash", "total", "petty_cash", "month", "year", "yr_month")

# Change NAs to 0
sales_data[is.na(sales_data)] <- 0

# Impute missing values
weather_data <- as.data.frame(weather_data %>% group_by(year, month) %>%
                                mutate(max_temp = ifelse(is.na(max_temp),
                                                         mean(max_temp, na.rm = TRUE), max_temp)))

weather_data <- as.data.frame(weather_data %>% group_by(year, month) %>%
                                mutate(rainfall = ifelse(is.na(rainfall),
                                                         mean(rainfall, na.rm = TRUE), rainfall)))

weather_data <- as.data.frame(weather_data %>% group_by(year, month) %>%
                                mutate(sun_sh_hr = ifelse(is.na(sun_sh_hr),
                                                         mean(rainfall, na.rm = TRUE), sun_sh_hr)))

weather_data <- as.data.frame(weather_data %>% group_by(year, month) %>%
                                mutate(spd_max_wind = ifelse(is.na(spd_max_wind),
                                                         mean(spd_max_wind, na.rm = TRUE), spd_max_wind)))

weather_data <- as.data.frame(weather_data %>% group_by(year, month) %>%
                                mutate(`9am_hum` = ifelse(is.na(`9am_hum`),
                                                         mean(`9am_hum`, na.rm = TRUE), `9am_hum`)))

weather_data <- as.data.frame(weather_data %>% group_by(year, month) %>%
                                mutate(`9am_cld_amnt` = ifelse(is.na(`9am_cld_amnt`),
                                                          mean(`9am_cld_amnt`, na.rm = TRUE), `9am_cld_amnt`)))
#-------------------------------------------------------------------------------
# Correlation
corr_weather <- subset(weather_data, select = -c(1, 7, 9, 13, 14, 19, 20, 22))
View(corr_weather)
ggcorr(corr_weather, label = TRUE)

corr_sales <- subset(sales_data, select = -c(1, 2, 10, 11, 12))
View(corr_sales)
ggcorr(corr_sales, label = TRUE)

#-------------------------------------------------------------------------------
#
delivery_sales <- subset(sales_data, select = -c(1, 2, 6, 7, 8, 9, 10, 11))
View(delivery_sales)

#-------------------------------------------------------------------------------
#
mean_rainfall_by_yrmonth <- weather_data %>% 
  group_by(yr_month) %>%
  summarise(
    mean_rainfall = mean(rainfall, na.rm = TRUE)
  )
View(mean_rainfall_by_yrmonth)

#
mean_sales_by_yrmonth <- sales_data %>%
  group_by(yr_month) %>%
  summarise(
    mean_sales = mean(total, na.rm = TRUE)
  )
View(mean_sales_by_yrmonth)

# 
mean_sales_rainfall <- cbind(mean_sales_by_yrmonth, mean_rainfall_by_yrmonth)
mean_sales_rainfall <- subset(mean_sales_rainfall, select = -c(3))
View(mean_sales_rainfall)

# Gather "mean_sales" and "mean_rainfall"
mean_sales_rainfall <- mean_sales_rainfall %>%
  gather("means", "sales_rainfall", -yr_month)

#
delivery_sales <- delivery_sales %>%
  gather("service_type", "sales", -yr_month, 1:3)

delivery_sales <- delivery_sales %>% 
  group_by(yr_month, service_type) %>%
  summarise(
    mean = mean(sales, na.rm = TRUE)
  )

#----------------------------------- Plots -------------------------------------
# Histogram of Rainfall
ggplot(weather_data, aes(x = rainfall)) +
  geom_histogram() +
  xlab("Rainfall (mm)") +
  ylab("Counts") +
  ggtitle("Distribution of Rainfall (mm)")

# Histogram of Income
ggplot(sales_data, aes(x = total)) +
  geom_histogram() +
  xlab("Sales ($)") +
  ylab("Counts") +
  ggtitle("Distribution of Sales ($)")

#
ggplot(weather_data, aes(x = month, y = rainfall)) +
  geom_point()

#
ggplot(sales_data, aes(x = month, y = total)) +
  geom_point()

# Time Series of Average Monthly Rainfall
ggplot(mean_rainfall_by_yrmonth, aes(x = yr_month, y = mean_rainfall)) +
  geom_line() +
  xlab("Time") +
  ylab("Mean rainfall (mm)") +
  ggtitle("Mean Rainfall (mm) of the Last 14 Months")

# Time Series of Average Monthly Sales
ggplot(mean_sales_by_yrmonth, aes(x = yr_month, y = mean_sales)) +
  geom_line() +
  xlab("Time") +
  ylab("Mean Sales ($)") +
  ggtitle("Mean Sales ($) of the Last 14 Months")

# Time Series of Sales and Rainfall
ggplot(mean_sales_rainfall, aes(x = yr_month, y = sales_rainfall)) +
  geom_line(aes(color = means))

# Time Series of Delivery Service Sales
ggplot(delivery_sales, aes(x = yr_month, y = mean)) +
  geom_line(aes(color = service_type)) +
  xlab("Time") +
  ylab("Mean Sales") +
  ggtitle("Average Delivery Sales Over the Last 14 Months")
